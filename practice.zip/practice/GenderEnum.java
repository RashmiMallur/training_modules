package java_basics.practice;

public enum GenderEnum {
	MALE, FEMALE, OTHER

}
