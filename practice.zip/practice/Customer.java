package java_basics.practice;

public class Customer {
	public int id;
	public String customerName;
	public byte age;
	public String city;
	public long mobileNo;
	public GenderEnum gender;
	

}
