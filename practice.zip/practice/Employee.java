package java_basics.practice;

public class Employee {
	public String stName;
	public byte age;
	public long mobileNo;
	public String city;

}
