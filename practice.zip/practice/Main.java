package java_basics.practice;

public class Main {

	public static void main(String[] args) {
		Employee e1=new Employee();// here e1 is stored in stack
		e1.stName = "Rashmi Mallur";//the name Rashmi Mallur is stored in heap
		e1.age=22;
		e1.mobileNo =1233256987L;
		e1.city = "RNR";
		
		System.out.println(e1.stName);
		System.out.println(e1.age);
		System.out.println(e1.mobileNo);
		System.out.println(e1.city);
		
		Employee e2 = new Employee();
		e2.stName = "Shailaija Mallur";
		e2.age =36;
		e2.mobileNo = 2345678901L;
		e2.city = "RNR";
		
		System.out.println(e2.stName);
		System.out.println(e2.age);
		System.out.println(e2.mobileNo);
		System.out.println(e2.city);
		
		
		
		
	}

}
