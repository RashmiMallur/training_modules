package java_basics.practice;

public class Bank {

	public static void main(String[] args) {
		Customer c1 = new Customer();
		c1.id = 003;
		c1.customerName = "James";
		c1.age = 32;
		c1.city = "Bangalore";
		c1.mobileNo = 45678913546L;
		c1.gender = GenderEnum.MALE;

		System.out.println("customer Id is: " + c1.id);
		System.out.println("Customer Name : " + c1.customerName);
		System.out.println("Customer age: " + c1.age);
		System.out.println("Customer city: " + c1.city);
		System.out.println("Customer mobile No.: " + c1.mobileNo);
		System.out.println("Customer gender: " + c1.gender);

	}

}
