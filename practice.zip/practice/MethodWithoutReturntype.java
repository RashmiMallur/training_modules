package java_basics.practice;

class Demo{
	int i,j,k;
	void sum(int m,int n) {
		k=m+n;
		System.out.println("The sum is "+k);
	}
}
public class MethodWithoutReturntype {
	
	public static void main(String[] args) {
		Demo d1=new Demo();
		d1.sum(20,34);
		
		
	}

}
