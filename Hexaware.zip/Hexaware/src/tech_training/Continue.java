package tech_training;

public class Continue {

	public static void main(String[] args) {
		Outer:
		for (int j = 1; j <= 3; j++) {
			for (int i = 1; i <= 10; i++) {
				if (i == 3)
					continue Outer;
				System.out.println(j + " " + i);
			}
			System.out.println("Out of innner loop");
		}
		System.out.println("Out ot the outer loop");
	}

}
