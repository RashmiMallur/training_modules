package tech_training;

public class Firstprg {

	public static void main(String[] args) {
		float radius = 10.78F;
		
        float area = 3.14f * radius * radius; 
		System.out.println("Area:  " + area);

	}

}
