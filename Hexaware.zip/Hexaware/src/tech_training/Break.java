package tech_training;

public class Break {

	public static void main(String[] args) {
		Outer:
		for (int j = 1; j <= 3; j++) {
			for (int i = 1; i <= 10; i++) {
				if (i == 4) {
					break Outer;

				}
				System.out.println(j+ " " + i);
			}
			System.out.println("Out of Loop");
		}
		System.out.println("Out of the loops");
	}
}
