package tech_training;

public class ArrayDemo {

	public static void main(String[] args) {
	int a[];
	int []b;
	int[] c = {6,7,5,43,23};
	
	a = new int[5];
	
	for(int i=0;i<a.length;i++) {
		System.out.println("Array a: " + a[i]);
	}
	b = new int[] {1,2,3,4,5};
	
	for(int i = 0;i<b.length;i++) {
		System.out.println("Array b: " + b[i]);
	}
	
	for(int i=0;i<c.length;i++) {
		System.out.println("Array c:" + c[i]);
	}

	}

}
