package tech_training;

import java.util.Scanner;

public class UserInput {

	public static void main(String[] args) {
	Scanner scInp = new Scanner(System.in);
	float radius = 0.0f;
	
	System.out.print("Enter the radius: ");
	radius = scInp.nextFloat();
	
	float area = 3.14f * radius * radius;
	System.out.println("Area: " + area);
	
	scInp.close();

	}

}
