package tech_training;

import java.util.Scanner;

public class NumberInArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the size of the array");
		int size=sc.nextInt();
		int[] b=new int[size];
		System.out.println("Enter the array elements: ");
		for(int i=0;i<=size-1;i++) {
			b[i]=sc.nextInt();
		}
		
		System.out.println("Enter the number to be searched in array: ");
		int find= sc.nextInt();
		
		for(int i=0;i<=size;i++) {
			if(b[i]==find) {
				System.out.println(i);
			}
		}
		
		sc.close();

	}

}
