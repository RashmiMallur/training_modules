package tech_training;

public class AdjacentSum {

	public static void main(String[] args) {
		int[] a = {6,7,5,43,23};
		int sum;
		for(int i=0;i<=a.length;i++) {
			sum=a[i]+a[i+1];
			System.out.println("Sum of "+ a[i] + " and " + a[i+1] + " is: " + sum);
		}

	}

}
