package tech_training;

public class Modulo {

	public static void main(String[] args) {
		float num=10.24f;
		float divisor = 2.34f;
		
		float rem=num % divisor;
		
		System.out.println(rem);

	}

}
