package tech_training;

import java.util.Scanner;

public class MainModuleArrya {
	
	public static void main(String[] args) {
		System.out.println("How many student objects created? ");
		Student.printCount();
		
		String name;
		int m1;
		int m2;
		
		String city = null;
		String state = null;
		
		Address address = null;
		
		Student students[] =new Student[3];
		
		Scanner scInput=new Scanner(System.in);
		
		System.out.println("Enter name: ");
		name = scInput.nextLine();
		
		System.out.println("Enter m1: ");
		m1 =scInput.nextInt();
		scInput.nextLine();
		
		System.out.println("Enter m2: ");
		m2 = scInput.nextInt();
		scInput.nextLine();
		
		System.out.println("Enter city: ");
		city = scInput.nextLine();
		
		
	}
}
