package tech_training;

import java.util.Scanner;

public class Grade {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		float percent=0.0f;
		
		System.out.print("Enter percentage: ");
		percent = sc.nextFloat();
		
		if(percent >= 75) {
			System.out.println("Distinction");
		}else if(percent >=60 && percent <75) {
			System.out.println("First Class");
		}else if (percent >=50 && percent <60) {
			System.out.println("Second Class");
		}else if(percent >=40 && percent <35) {
			System.out.println("Pass");
		}else {
			System.out.println("Fail");
		}
		sc.close();

	}

}
