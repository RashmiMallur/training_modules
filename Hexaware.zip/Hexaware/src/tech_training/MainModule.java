package tech_training;

import java.util.Scanner;

public class MainModule {

	public static void main(String[] args) {
		int rollno;
		String name;
		int m1;
		int m2; 
		
		String city = null;
		String state = null;
		
		Address address =null; 
		
		float percent =0.0f;
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter rollno: ");
		rollno = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter name: ");
		name = sc.nextLine();
		
		System.out.println("Enter m1: ");
		m1 = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter m2: ");
		m2 = sc.nextInt();
		sc.nextLine();
		
		Student student = new Student(rollno,name,m1,m2);
		
		student.output();
		
		System.out.println("Enter name: ");
		name = sc.nextLine();
		
		System.out.println("Enter m1: ");
		m1=sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter m2: ");
		m2 = sc.nextInt();
		sc.nextLine();
		
		Student stu = new Student(name,m1,m2);
		stu.output();
		
		student.setPercent(98); 
		percent = student.getPercent();
		
		
		sc.close();
		
	}
}