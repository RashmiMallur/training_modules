package tech_training;

public class Student {
	private static int rollno;
	private String name;
	private int m1;
	private int m2;
	private int total;
	private float percent;
	
public Student (String name,int m1,int m2) {
		
		super();
		this.rollno  =++rollno;
		this.name =name;
		this.m1 = m1;
		this.m2 = m2;
		
		this.total = m1+m2;
		this.percent= total/2.0f;
	}
	
	public Student (int rollno,String name,int m1,int m2) {
		
		super();
		this.rollno  =++rollno;
		this.name =name;
		this.m1 = m1;
		this.m2 = m2;
		
		this.total = m1+m2;
		this.percent= total/2.0f;
	}
	
	public float getPercent() {
		return this.percent;
	}
	
	public void setPercent(int percent) {
		this.percent = percent;
	}
	
	public void output() {
		System.out.println(rollno);
		System.out.println(name);
		System.out.println(m1);
		System.out.println(m2);
		System.out.println(total);
		System.out.println(percent);
	}
	public static void printCount() {
		System.out.println(rollno);
	}
		

	}


