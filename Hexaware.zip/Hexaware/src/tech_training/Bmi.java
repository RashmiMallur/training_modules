package tech_training;

import java.util.Scanner;

public class Bmi {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int weight = 0;
		float height = 0;
		float bmi=0.0f;
		
		System.out.print("Enter the values of weight and height: ");
		weight = sc.nextInt();
		height = sc.nextFloat();
		
		bmi = weight /height;
		System.out.println("Body Mass Index(BMI): " + bmi);
		
		if(bmi<18) {
			System.out.println("Underweight");
		}else if (bmi>=18 && bmi<24){
			System.out.println("Normal");
		}else if(bmi>=24 && bmi <30) {
			System.out.println("Fat");
		}else if(bmi>30) {
			System.out.println("Obese");
		}
		
		
		
		
		sc.close();

	}

}
