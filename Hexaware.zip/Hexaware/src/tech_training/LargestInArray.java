package tech_training;

public class LargestInArray {

	public static void main(String[] args) {
		int c[] = {3,2,57,76,9};
		int max;
		max=c[0];
		for(int i=1;i<c.length;i++) {
			if(c[i]>max) {
				max=c[i];
			}
		}
		System.out.println("Largest element in array is: " + max);

	}

}
