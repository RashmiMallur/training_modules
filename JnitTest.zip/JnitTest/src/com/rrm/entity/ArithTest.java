package com.rrm.entity;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ArithTest {

	private Arith arith;
	
	@Before
	public void setUp() throws Exception {
	    arith  = new Arith();
	}

	@After
	public void tearDown() throws Exception {
		arith = null;
	}

	@Test
	public final void testAdd() {
		assertTrue(arith.add(20,20)==40);
	}

	@Test
	public final void testSubtract() {
		assertTrue(arith.subtract(20,20)==0);
	}

	@Test
	public final void testMultiply() {
		assertTrue(arith.multiply(20,20)==400);
	}

	@Test
	public final void testDivide() {
		assertTrue(arith.divide(20,20)==1);
	}

}
